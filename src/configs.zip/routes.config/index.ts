export {
    protectedRoutes,
    publicRoutes,
    protectedUserRoutes,
} from './routes.config'
